/* Settings popup: stores pacing and type filters under chrome.storage.local.settings */
const DEFAULTS = {
  minDelay: 800,
  maxDelay: 2400,
  longPauseEveryMin: 6,
  longPauseEveryMax: 14,
  longPauseMin: 3500,
  longPauseMax: 9000,
  includePlain: true,
  includeEdited: true,
  includeVideos: false,
  includeOther: false,
  maxPerRun: 0,
  maxSizeMB: 0,
  maxScanPages: 0,
  stopAfterNoCandidates: 0,
  youngerThan: '',
  removeSessions: false,
  removeProjects: false,
  downloadFirst: false,
  folder: '',
  savePrompts: true,
};

const NUMBER_FIELDS = [
  ['minDelay', 'minDelay'],
  ['maxDelay', 'maxDelay'],
  ['longPauseEveryMin', 'every'],
  ['longPauseEveryMax', 'everyMax'],
  ['longPauseMin', 'pause'],
  ['longPauseMax', 'pauseMax'],
  ['maxPerRun', 'maxPerRun'],
  ['maxSizeMB', 'maxSizeMB'],
  ['maxScanPages', 'maxScanPages'],
  ['stopAfterNoCandidates', 'stopAfterNoCandidates'],
];

const CHECKBOXES = [
  'removeSessions',
  'removeProjects',
  'includePlain',
  'includeEdited',
  'includeVideos',
  'includeOther',
  'downloadFirst',
  'savePrompts',
];

/* Mirrors content.js parseAge: empty is 0, unreadable is -1. Used to refuse a typo. */
function parseAge(text) {
  const t = String(text || '').trim().toLowerCase();
  if (!t) return 0;
  const units = { y: 31536000000, m: 2592000000, mo: 2592000000, w: 604800000, d: 86400000, h: 3600000 };
  const token = /(\d+(?:\.\d+)?)\s*(mo|y|m|w|d|h)/g;
  let total = 0;
  let seen = false;
  let m;
  while ((m = token.exec(t))) {
    total += parseFloat(m[1]) * units[m[2]];
    seen = true;
  }
  const leftover = t.replace(/(\d+(?:\.\d+)?)\s*(mo|y|m|w|d|h)/g, '').replace(/[\s,]+/g, '');
  if (!seen || leftover || total <= 0) return -1;
  return total;
}

/* Downloads land under Downloads/<folder>, so keep it to one plain path segment. */
function cleanFolder(value) {
  const cleaned = String(value || '')
    .replace(/[<>:"\\|?*]/g, '')
    .replace(/^[.\/\s]+|[.\/\s]+$/g, '')
    .replace(/\s+/g, ' ')
    .slice(0, 60);
  return cleaned;
}

/* The folder and prompt fields only mean something while saving is on. */
function syncSave(settings) {
  const on = document.getElementById('downloadFirst').checked;
  const folder = document.getElementById('folder');
  const prompts = document.getElementById('savePrompts');
  folder.disabled = !on;
  prompts.disabled = !on;
  folder.style.opacity = on ? '' : '0.45';
  prompts.parentElement.style.opacity = on ? '' : '0.45';
  if (settings) {
    folder.value = on ? settings.folder || '' : folder.value;
  }
}

function fill(settings) {
  const s = { ...DEFAULTS, ...(settings || {}) };
  // Migrate the pre 1.1 single "includeImages" flag.
  if (s.includeImages !== undefined) {
    if (s.includePlain === undefined) s.includePlain = s.includeImages !== false;
    if (s.includeEdited === undefined) s.includeEdited = s.includeImages !== false;
  }
  for (const [key, id] of NUMBER_FIELDS) document.getElementById(id).value = s[key];
  for (const key of CHECKBOXES) document.getElementById(key).checked = s[key] !== false && s[key] === true;
  document.getElementById('folder').value = s.folder || '';
  document.getElementById('youngerThan').value = s.youngerThan || '';
  syncSave(s);
}

function read() {
  const v = (id) => Number(document.getElementById(id).value);
  const out = {
    minDelay: Math.min(60000, Math.max(300, v('minDelay') || DEFAULTS.minDelay)),
    maxDelay: Math.min(120000, Math.max(300, v('maxDelay') || DEFAULTS.maxDelay)),
    longPauseEveryMin: Math.min(200, Math.max(2, v('every') || DEFAULTS.longPauseEveryMin)),
    longPauseEveryMax: Math.min(200, Math.max(2, v('everyMax') || DEFAULTS.longPauseEveryMax)),
    longPauseMin: Math.min(300000, Math.max(1000, v('pause') || DEFAULTS.longPauseMin)),
    longPauseMax: Math.min(600000, Math.max(1000, v('pauseMax') || DEFAULTS.longPauseMax)),
    maxPerRun: Math.min(50000, Math.max(0, v('maxPerRun') || 0)),
    maxSizeMB: Math.min(4096, Math.max(0, Math.round((v('maxSizeMB') || 0) * 10) / 10)),
    maxScanPages: Math.min(10000, Math.max(0, Math.round(v('maxScanPages') || 0))),
    stopAfterNoCandidates: Math.min(10000, Math.max(0, Math.round(v('stopAfterNoCandidates') || 0))),
  };
  for (const key of CHECKBOXES) out[key] = document.getElementById(key).checked;
  out.folder = cleanFolder(document.getElementById('folder').value);
  out.youngerThan = document
    .getElementById('youngerThan')
    .value.trim()
    .replace(/\s+/g, ' ')
    .toLowerCase();
  if (out.maxDelay < out.minDelay) out.maxDelay = out.minDelay;
  if (out.longPauseEveryMax < out.longPauseEveryMin) out.longPauseEveryMax = out.longPauseEveryMin;
  if (out.longPauseMax < out.longPauseMin) out.longPauseMax = out.longPauseMin;
  return out;
}

const store = (globalThis.chrome && chrome.storage && chrome.storage.local) || null;

if (store) {
  store.get('settings').then(
    (v) => fill(v && v.settings),
    () => fill(DEFAULTS)
  );
} else {
  fill(DEFAULTS); // keeps the form usable when storage is unreachable
}

document.getElementById('save').addEventListener('click', async () => {
  const settings = read();
  const status = document.getElementById('status');
  if (settings.youngerThan && parseAge(settings.youngerThan) < 0) {
    status.textContent = 'Age: use a value like 1d 6h, or leave it empty.';
    return;
  }
  if (!store) {
    status.textContent = 'Storage is unavailable in this context.';
    return;
  }
  await store.set({ settings });
  fill(settings);
  status.textContent = 'Saved. Applies to the open library tab.';
  setTimeout(() => {
    status.textContent = '';
  }, 3000);
});

document.getElementById('youngerThan').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') document.getElementById('save').click();
});

for (const [, id] of NUMBER_FIELDS) {
  document.getElementById(id).addEventListener('keydown', (e) => {
    if (e.key === 'Enter') document.getElementById('save').click();
  });
}

/* Proves the download path really works for the chosen folder. */
document.getElementById('downloadFirst').addEventListener('change', () => syncSave());
syncSave();

/* Hands the run to the service worker, which finds or opens a Grok tab. */
document.getElementById('delall').addEventListener('click', async () => {
  const status = document.getElementById('status');
  const settings = read();
  const anyType =
    settings.removeSessions ||
    settings.removeProjects ||
    settings.includePlain ||
    settings.includeEdited ||
    settings.includeVideos ||
    settings.includeOther;
  if (!anyType) {
    status.textContent = 'Turn on at least one type first.';
    return;
  }
  if (settings.youngerThan && parseAge(settings.youngerThan) < 0) {
    status.textContent = 'Age: use a value like 1d 6h, or leave it empty.';
    return;
  }
  if (store) await store.set({ settings });
  fill(settings);
  status.textContent = 'Starting in your Grok tab…';
  try {
    const res = await chrome.runtime.sendMessage({ type: 'glc-run-all' });
    if (res && res.ok) {
      status.textContent = 'Scanning in your Grok tab. Confirm there.';
    } else {
      status.textContent = 'Could not start: ' + ((res && res.error) || 'no answer from the extension');
    }
  } catch (err) {
    status.textContent = 'Could not start: ' + String((err && err.message) || err);
  }
});

document.getElementById('selftest').addEventListener('click', async () => {
  const status = document.getElementById('status');
  const folder = cleanFolder(document.getElementById('folder').value);
  status.textContent = 'Testing downloads in ' + folder + '…';
  try {
    const res = await chrome.runtime.sendMessage({ type: 'glc-selftest', folder });
    status.textContent = res && res.ok
      ? 'Saved ' + res.path
      : 'Failed: ' + ((res && res.error) || 'no answer from the extension');
  } catch (err) {
    status.textContent = 'Failed: ' + String((err && err.message) || err);
  }
});
